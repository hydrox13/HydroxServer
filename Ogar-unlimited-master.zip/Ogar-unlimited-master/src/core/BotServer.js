'use strict';
module.exports = class BotServer {
  constructor(gameServer) {
    this.gameServer = gameServer;
  }
  init() {}
  start() {}
  update(dt) {}
};
