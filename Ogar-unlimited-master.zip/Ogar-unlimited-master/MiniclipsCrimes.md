#### Moneyshit (aka miniclip) has committed these crimes against all the agario community
1. Removed private servers
2. Made us pay for coins
3. made us pay for skins
4. made graphics awful
5. ruined the game
6. Turned agario into a cash cow
7. Ignored the community
8. Acted in their own behalf
9. Obliterated extensions
10. LAG
11. Lied about fixing private servers!
12. And much more 

##### SHAME, fore SHAME on moneyshit
